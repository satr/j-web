CREATE TRIGGER `Product_Stock_Insert`
AFTER INSERT ON `Product`
FOR EACH ROW
  BEGIN
    INSERT INTO Stock (ProductID, Amount)
    VALUES (NEW.ID, 0);
  END